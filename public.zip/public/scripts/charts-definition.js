window.addEventListener('load', onload);

function onload(event){
  chartV = createVoltageChart();
  chartC = createCurrentChart();
  chartP = createPowerChart();
}

// Create voltage Chart
function createVoltageChart() {
  var chart = new Highcharts.Chart({
    chart:{ 
      renderTo:'chart-voltage',
      type: 'spline' 
    },
    series: [
      {
        name: 'PZEM-004T'
      }
    ],
    title: { 
      text: undefined
    },
    plotOptions: {
      line: { 
        animation: false,
        dataLabels: { 
          enabled: true 
        }
      }
    },
    xAxis: {
      type: 'datetime',
      dateTimeLabelFormats: { second: '%H:%M:%S' }
    },
    yAxis: {
      title: { 
        text: 'Voltage in Volts (V)' 
      }
    },
    credits: { 
      enabled: false 
    }
  });
  return chart;
}

// Create current Chart
function createCurrentChart(){
  var chart = new Highcharts.Chart({
    chart:{ 
      renderTo:'chart-current',
      type: 'spline'  
    },
    series: [{
      name: 'PZEM-004T'
    }],
    title: { 
      text: undefined
    },    
    plotOptions: {
      line: { 
        animation: false,
        dataLabels: { 
          enabled: true 
        }
      },
      series: { 
        color: '#50b8b4' 
      }
    },
    xAxis: {
      type: 'datetime',
      dateTimeLabelFormats: { second: '%H:%M:%S' }
    },
    yAxis: {
      title: { 
        text: 'Current (A)' 
      }
    },
    credits: { 
      enabled: false 
    }
  });
  return chart;
}

// Create Power Chart
function createPowerChart() {
  var chart = new Highcharts.Chart({
    chart:{ 
      renderTo:'chart-power',
      type: 'spline'  
    },
    series: [{
      name: 'PZEM-004T'
    }],
    title: { 
      text: undefined
    },    
    plotOptions: {
      line: { 
        animation: false,
        dataLabels: { 
          enabled: true 
        }
      },
      series: { 
        color: '#A62639' 
      }
    },
    xAxis: {
      type: 'datetime',
      dateTimeLabelFormats: { second: '%H:%M:%S' }
    },
    yAxis: {
      title: { 
        text: 'Power (W)' 
      }
    },
    credits: { 
      enabled: false 
    }
  });
  return chart;
}